# Free Instance Fetcher

## [v11.0.4](https://github.com/LiangYuxuan/FreeInstanceFetcher/tree/v11.0.4) (2024-09-29)
[Full Changelog](https://github.com/LiangYuxuan/FreeInstanceFetcher/compare/v11.0.3...v11.0.4) [Previous Releases](https://github.com/LiangYuxuan/FreeInstanceFetcher/releases)

- feat: update character list  
